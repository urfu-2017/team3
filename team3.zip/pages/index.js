import React, { Component } from 'react';

export default class NotePage extends Component {
    render() {
        return (
            <h1>Hello world</h1>
        );
    }
}
